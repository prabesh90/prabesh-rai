import os
import time as cabdulahi

def prRed(skk): print("\033[91m {}\033[00m" .format(skk)) 
def prGreen(skk): print("\033[92m {}\033[00m" .format(skk)) 
def prYellow(skk): print("\033[93m {}\033[00m" .format(skk)) 
def prLightPurple(skk): print("\033[94m {}\033[00m" .format(skk)) 
def prPurple(skk): print("\033[95m {}\033[00m" .format(skk)) 
def prCyan(skk): print("\033[96m {}\033[00m" .format(skk)) 
def prLightGray(skk): print("\033[97m {}\033[00m" .format(skk)) 
def prBlack(skk): print("\033[98m {}\033[00m" .format(skk)) 

green = '\033[32;1m'

gta = '@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@@'

white = '\033[1;37m' # White 
red = '\033[31m' # red
orange = '\033[33m' # orange
blue = '\033[34m' # blue
p  = '\033[35m' # purple
C  = '\033[36m' # cyan


class banner:
    def __init__(self):
        print C+orange+"""
  __ _     _
 / _| |__ | |__    _
| |_| '_ \| '_ \ _| |_  Facebook Bruteforce
|  _| |_) | |_) |_   _|  Faster 1.0 kps
|_| |_.__/|_.__/  |_|     Added More Info
          [FBB+ Facebook Bruteforce Tool]
        [@Created By Cabdualahi Sharif] """+C+p+"""
              Youtube Channel: Somali 4You
              Facebook Page: Somali 4You"""
        cabdulahi.sleep(2)
        print
        
        
        
        
       