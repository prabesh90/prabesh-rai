# fbb
FBB+ tool for facebook bruteforce attack 
# follow installation 
# $ git clone https://github.com/Cabdulahi/fbb
# $ cd fbb
# $ chmod +X 
# $ bash install.sh
# $ python2 fbb+.py
